//
//  Foundations_Theo_05App.swift
//  Foundations-Theo-05
//
//  Created by Aluno Mack on 11/07/25.
//

import SwiftUI

@main
struct Foundations_Theo_05App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
